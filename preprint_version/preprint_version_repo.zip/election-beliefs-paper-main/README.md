# election-beliefs-paper

Authors: Rotem Botvinik-Nezer, Matt Jones and Tor D. Wager

Preprint link: https://psyarxiv.com/yzcm7

This repo includes all data and code for the paper, including all analyses and figures.
